<?php
/**
 * Template for developer-info
 *
 * @package rt_Slideshow
 */

?>
<div class="inside">
	<h2 class="highlight"><strong>Hardik Panchal</strong></h2>
	<p>
		<span class="icon"><i class="fa fa-envelope"></i></span>
		<a href="mailto:someone@example.com">hardikpanchal551@gmail.com</a>
	</p>
	<p>
		<span class="icon"><i class="fa fa-university"></i></span>
		<span>LDRP Institute of Technology and Research, Gandhinagar</span>
	</p>
</div>
